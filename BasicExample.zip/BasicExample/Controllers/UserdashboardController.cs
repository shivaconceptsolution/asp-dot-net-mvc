﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BasicExample.Models;
namespace BasicExample.Controllers
{
    public class UserdashboardController : Controller
    {
        //
        // GET: /Userdashboard/
        Database1Entities db = new Database1Entities();
        public ActionResult Index()
        {
            var s = db.Registrations.Find(TempData["key"].ToString());
            TempData.Keep();
            return View(s);
        }

    }
}
