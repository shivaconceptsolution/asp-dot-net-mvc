﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BasicExample.Models;
namespace BasicExample.Controllers
{
    public class LoginController : Controller
    {
        Database1Entities db = new Database1Entities();
        
        //
        // GET: /Login/

        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Registration r)
        {
            var s = (from c in db.Registrations where c.UserID.Equals(r.UserID) && c.Password.Equals(r.Password) select c).FirstOrDefault();
            if (s != null)
            {
                TempData["key"] = s.UserID;
                TempData.Keep();
                return RedirectToAction("Index","Userdashboard");
            }
            else
            {
                ViewBag.data = "Invalid userid and password";
            }
            return View();
        }

    }
}
