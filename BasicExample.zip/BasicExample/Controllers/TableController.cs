﻿using System;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BasicExample.Models;
namespace BasicExample.Controllers
{
    public class TableController : Controller
    {
        //
        // GET: /Table/

        public ActionResult Index()
        {
            ViewBag.data1 = "";
            return View();
        }
        [HttpPost]
      /*  public ActionResult Index(FormCollection obj) // formcollection
        {
            int num = Convert.ToInt16(obj["txtnum"].ToString());
           // String [] s = new String[10];
           // int index = 0;
            ArrayList s = new ArrayList();
            for (int i = 1; i <= 10; i++)
            {
                s.Add(num * i);
                
            }
            ViewBag.data1 = obj["txtnum"].ToString();
            ViewBag.data = s;
            return View();
        }
        public ActionResult Index(string txtnum) // parameter
        {
            int num = Convert.ToInt16(txtnum);
            // String [] s = new String[10];
            // int index = 0;
            ArrayList s = new ArrayList();
            for (int i = 1; i <= 10; i++)
            {
                s.Add(num * i);

            }
            ViewBag.data1 = txtnum;
            ViewBag.data = s;
            return View();
        }
        public ActionResult TableLogic() // Request
        {
            int num = Convert.ToInt16(Request["txtnum"]);
            // String [] s = new String[10];
            // int index = 0;
            ArrayList s = new ArrayList();
            for (int i = 1; i <= 10; i++)
            {
                s.Add(num * i);

            }
            ViewBag.data1 = Request["txtnum"];
            ViewBag.data = s;
            return View("Index");
        }*/
        public ActionResult TableLogic(TableModel t) // Request
        {
            
            // String [] s = new String[10];
            // int index = 0;
            ArrayList s = new ArrayList();
            for (int i = 1; i <= 10; i++)
            {
                s.Add(t.num * i);

            }
            ViewBag.data1 = Request["txtnum"];
            ViewBag.data = s;
            return View("Index");
        }
    }
}
